
#ifndef  BOOL_INC
#define  BOOL_INC

// aquí van las DECLARACIONES del tipo Bool
enum {FALSE = 0, TRUE = !0};
typedef unsigned int Bool;


#endif   /* ----- #ifndef BOOL_INC  ----- */
